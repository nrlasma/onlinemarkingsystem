<?php

@include 'config.php';

session_start();

if(!isset($_SESSION['user_name'])){
   header('location:login_form.php');
}

?>

<?php include "templates/header.php"; ?>

<div class="topnav">
   <a href="user_page.php">Home</a>
   <a href="user_page1.php">Presentation</a>
   <a href="user_page2.php">Update</a>
   <a href="logout.php" style="float:right">Logout</a>
</div>

<div class="row">
  <div class="leftcolumn">
  
    <div class="card">
      
	<img src="image/photo2.png" alt="steps" width="740" height="688" class="center">  
	  
    </div>
	
  </div>
  <div class="rightcolumn">
    <div class="card">
      <h2>Profile</h2>
	
	  <h2>Welcome <span><?php echo $_SESSION['user_name'] ?></span></h2>
      <p> This is Participant Page</p>
    </div>
  </div>
  
</div>



<?php include "templates/footer.php"; ?>