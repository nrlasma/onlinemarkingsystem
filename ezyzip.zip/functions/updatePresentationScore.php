<?php 

session_start();
include("../config.php");

if($_SERVER["REQUEST_METHOD"] == "POST") {

    $judge_id = $_SESSION["judger_name"];
   
    $sql = "";
    foreach(array_combine($_POST["presentation_id"], $_POST["score"]) as $presentation_id => $score) {
        $sql .= "UPDATE presentations SET score = '$score', judged_by = '$judge_id' WHERE presentation_id = '$presentation_id';";
    }

    if(!mysqli_multi_query($conn, $sql)) {
        echo "<script>alert('Update Presentation Score Failed'); window.history.go(-1);</script>";
        exit();
    } else {
        echo "<script>alert('Update Presentation Score Successfully'); window.location='../judger_page1.php';</script>";
        exit();
    }

}


?>