<?php 

session_start();
include("../config.php");

$id = intval($_GET["id"]);

$sql = "DELETE FROM presentations WHERE presentation_id = '$id'";

if(!mysqli_query($conn, $sql)) {
    echo "<script>alert('Delete Presentation Failed'); window.history.go(-1);</script>";
    exit();
} else {
    echo "<script>alert('Delete Presentation Successfully'); window.location='../user_page2.php';</script>";
    exit();
}

?>