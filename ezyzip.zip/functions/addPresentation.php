<?php 

session_start();
include("../config.php");

if($_SERVER["REQUEST_METHOD"] == "POST") {

    $user_id = intval($_SESSION["id"]);
    $target_dir = "../assets/presentations/";
    $target_file = $target_dir . basename($_FILES["file"]["name"]);

    if($_FILES["file"]["size"] < 1) {
        echo "<script>alert('Please Upload Your Presentation'); window.history.go(-1);</script>";
        exit();
    }

    if(!move_uploaded_file($_FILES["file"]["tmp_name"], $target_file)) {
        echo "<script>alert('Upload Presentation Failed'); window.history.go(-1);</script>";
        exit();
    }

    $sql = "INSERT INTO presentations (user_id, presentation_path) VALUES ('$user_id', '$target_file')";

    if(!mysqli_query($conn, $sql)) {
        echo "<script>alert('Upload Presentation Failed'); window.history.go(-1);</script>";
        exit();
    } else {
        echo "<script>alert('Upload Presentation Successfully'); window.location='../user_page2.php';</script>";
        exit();
    }

}


?>