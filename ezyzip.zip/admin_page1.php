<?php

@include 'config.php';

session_start();

if(!isset($_SESSION['admin_name'])){
   header('location:login_form.php');
}

?>

<?php include "templates/header.php"; ?>

<div class="topnav">
  <a href="admin_page.php">Home</a>
  <a href="admin_page1.php">Product</a>
 
  
  <a href="logout.php" style="float:right">Logout</a>
</div>

<div class="row">
  <div class="leftcolumn">
    <div class="card">
      <h2>List of Participant and Marks</h2>
	  
	  <table id="user">
      <tr>
        <th>Participant Name</th>
        <th>Product</th>
        <th>Score</th>
        <th>Judges Name</th>
      </tr>

      <?php 
      $sql = "SELECT presentations.*, user_form.name
      FROM presentations
      INNER JOIN user_form
      ON presentations.user_id = user_form.id
      WHERE presentations.user_id = user_form.id
      ORDER BY presentations.created_at DESC";

      $result = mysqli_query($conn, $sql);

      while($row = mysqli_fetch_assoc($result)) {
      ?>
      <tr>
        <td><?php echo $row["name"]; ?></td>
        <td>
		 <form action="<?php echo substr($row["presentation_path"], 3); ?>" target="_blank">
             <input class=" button button1" type="submit" value="View">
         </form>
      
        </td>
        <td><?php echo empty($row["score"]) ? 'Pending' : $row["score"] . "%"; ?></td>
        <td><?php echo empty($row["judged_by"]) ? 'Pending' : $row["judged_by"]; ?></td>
      </tr>
      <?php } ?>
    
    </table>
    
      
    </div>
 
  </div>
  <div class="rightcolumn">
    <div class="card">
      <h2>Profile</h2>
   
	  <h2>Welcome <span><?php echo $_SESSION['admin_name'] ?></span></h2>
      <p> This is Admin Page</p>
    </div>
   
   
  </div>
</div>

<?php include "templates/footer.php"; ?>