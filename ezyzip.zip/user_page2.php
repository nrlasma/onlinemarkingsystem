<?php

@include 'config.php';

session_start();

if(!isset($_SESSION['user_name'])){
   header('location:login_form.php');
}

?>

<?php include "templates/header.php"; ?>

<div class="topnav">
   <a href="user_page.php">Home</a>
   <a href="user_page1.php">Presentation</a>
   <a href="user_page2.php">Update</a>
   <a href="logout.php" style="float:right">Logout</a>
</div>

<div class="row">
  <div class="leftcolumn">
    <div class="card">
      
	  <table id="user">
      <tr> 
        <th>Participant Name</th>
        <th>Email </th>
        <th>Presentation</th>
        <th>Action</th>
      </tr>
  
      <?php 
      $user_id = intval($_SESSION["id"]);
      $sql = "SELECT presentations.*, user_form.name, user_form.email 
      FROM presentations 
      INNER JOIN user_form
      ON presentations.user_id = user_form.id
      WHERE presentations.user_id = '$user_id'";
      $result = mysqli_query($conn, $sql);

      while($row = mysqli_fetch_assoc($result)) {
      ?>
      <tr>
        <td><?php echo $row["name"]; ?></td>
        <td><?php echo $row["email"]; ?></td>
        <td>
		 <form action="<?php echo substr($row['presentation_path'],3); ?>" target="_blank">
             <input class=" button button1" type="submit" value="View">
         </form>
 
        </td>
        <td>
		 <form action="edit-presentation.php?id=<?php echo $row["presentation_id"]; ?>">
             <input class=" button button2" type="submit" value="Edit">
         </form>
		  <form action="functions/deletePresentation.php?id=<?php echo $row["presentation_id"]; ?>" onclick="return confirm('Are you sure you want to delete?')">
             <input class=" button button3" type="submit" value="Delete">
         </form>
          
        </td>
      </tr>  
      <?php } ?>
  </table>

<br>
<br>

 
    </div>
   
  </div>
  <div class="rightcolumn">
    <div class="card">
      <h2>Profile</h2>
	
	  <h2>Welcome <span><?php echo $_SESSION['user_name'] ?></span></h2>
      <p> This is Participant Page</p>
    </div>
  
  </div>
</div>

<?php include "templates/footer.php"; ?>