<?php

@include 'config.php';

session_start();

if(!isset($_SESSION['admin_name'])){
   header('location:login_form.php');
}

?>

<?php include "templates/header.php"; ?>
<div class="topnav">
  <a href="admin_page.php">Home</a>
  <a href="admin_page1.php">Product</a>

  
  <a href="logout.php" style="float:right">Logout</a>
</div>

<div class="row">
  <div class="leftcolumn">
    <div class="card">
      
	 <img src="image/photo1.png" alt="aboutus" width="740" height="688">  
    
      
    </div>
 
  </div>
  <div class="rightcolumn">
    <div class="card">
      <h2>Profile</h2>
   
	  <h2>Welcome <span><?php echo $_SESSION['admin_name'] ?></span></h2>
      <p> This is Admin Page</p>
    </div>
  </div>
</div>


<?php include "templates/footer.php"; ?>
