</body>
<div class="footer">
  <div class="row">
  <div class="column">
    <h3>Contact Us</h3>
    <p> Tel : 03 5543 8581 | 03 55211701  </p>
    <p> webmedia@uitm.edu.my</p>
    <p>Universiti Teknologi MARA (UiTM) 
    40450 Shah Alam, Selangor Darul EhsanMalaysia</p>
  </div>
  
  <div class="column">
    <h3>Useful Links </h3>
    <p><a href="https://hea.uitm.edu.my/v4/index.php/calendars/academic-calendar">Academic Calendar</a></p>
    <p><a href="https://library.uitm.edu.my/en/">Library</a></p>
    <p><a href="https://news.uitm.edu.my/">News</a></p>
    <p><a href="https://www.uitm.edu.my/index.php/en/e-complaint">E-Complaint</a></p>
  </div>
  
  <div class="column">
    <p>Copyright UiTM News Hub. All rights reserved.<p>
	<p>Disclaimer & Copyright | Privacy Statement | ICT Security Policy</p>
  </div>
</div>

  
</html>