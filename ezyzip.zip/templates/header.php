<!DOCTYPE html>
<html>
<head>
<title>Participant Page</title>


<style>

* {
  box-sizing: border-box;
}

body {
  font-family: Arial;
  padding: 10px;
  background: #f1f1f1;
  text-align: justify;
  text-justify: inter-word;
 
}

table {
  border-collapse: collapse;
  width: 100%;
}

th, td {
  text-align: left;
  padding: 8px;
}

tr:nth-child(even){background-color: #f2f2f2}

th {
  background-color: #3C99DC;
  color: white;
}


/* Header/Blog Title */
.header {
  padding: 30px;
  text-align: center;
  background: white;
}

.header h1 {
  font-size: 50px;
}

#display-image{
    width: 100%;
    justify-content: center;
    padding: 5px;
    margin: 15px;
	width: 25px;
    height: 15px
}
img {
  display: block;
  margin-left: auto;
  margin-right: auto;
}

/* Style the top navigation bar */
.topnav {
  overflow: hidden;
  background-color: #784b84;
}

/* Style the topnav links */
.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

/* Change color on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/* Create two unequal columns that floats next to each other */
/* Left column */
.leftcolumn {   
  float: left;
  width: 75%;
}
.button {
  border: none;
  color: white;
  padding: 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.button1 {
	border-radius: 10px;
	background-color: #135e96
	}
	
.button2 {
	border-radius: 10px;
	background-color: #1ed14b;
	}
	
.button3 {
	border-radius: 10px;
	background-color: red;
	}

/* Right column */
.rightcolumn {
  float: left;
  width: 25%;
  background-color: #f1f1f1;
  padding-left: 20px;
}

/* Create three equal columns that floats next to each other */
.column {
  float: left;
  width: 33.33%;
  padding: 15px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Add a card effect for articles */
.card {
  background-color: white;
  padding: 20px;
  margin-top: 20px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

/* Footer */
.footer {
  padding: 5px;
  text-align: left;
  color: #f2f2f2;
  background: #784b84;
  margin-top: 20px;
}

a:link, a:visited {
  background-color: #white;
  color: white;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}


/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 800px) {
  .leftcolumn, .rightcolumn {   
    width: 100%;
    padding: 0;
  }
}

/* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
@media screen and (max-width: 400px) {
  .topnav a {
    float: none;
    width: 100%;
  }
}
</style>


</head>
<body>

<div class="header">
<pre><img style = "display: inline;" src="UiTM_Universiti_Teknologi_MARA_logo.png" alt="uitm" width="250" height="100">       <h1 style = "display: inline;" >Online Marking System</h1> </pre>                 
</div>