<?php

@include 'config.php';

session_start();

if(!isset($_SESSION['user_name'])){
   header('location:login_form.php');
}

?>

<!DOCTYPE html>
<html>
<head>
<title>Participant Page</title>


<style>

* {
  box-sizing: border-box;
}

body {
  font-family: 'Arial', Helvetica;
  padding: 10px;
  background: #f1f1f1;
  height: 100%
}

/* Header/Blog Title */
.header {
  padding: 30px;
  text-align: center;
  background: white;
}

.header h1 {
  font-size: 50px;
}

#display-image{
    width: 100%;
    justify-content: center;
    padding: 5px;
    margin: 15px;
	width: 25px;
    height: 15px
}


/* Style the top navigation bar */
.topnav {
  overflow: hidden;
  background-color: #784b84;
}

/* Style the topnav links */
.topnav a {
  float: left;
  display: block;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

/* Change color on hover */
.topnav a:hover {
  background-color: #ddd;
  color: black;
}

/* Create two unequal columns that floats next to each other */
/* Left column */
.leftcolumn {   
  float: left;
  width: 75%;
  height : 80% ;
}

/* Right column */
.rightcolumn {
  float: left;
  width: 25%;
  background-color: #f1f1f1;
  padding-left: 20px;
}

/* Create three equal columns that floats next to each other */
.column {
  float: left;
  width: 33.33%;
  padding: 15px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}


/* Add a card effect for articles */
.card {
  background-color: white;
  padding: 20px;
  margin-top: 20px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

input[type=submit] {
  width: 50%;
  background-color: #784b84;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}


/* Footer */
.footer {
  padding: 5px;
  text-align: left;
  color: #f2f2f2;
  background: #784b84;
  margin-top: 20px;
    font-family: 'Open Sans', sans-serif;
}

a:link, a:visited {
  background-color: #white;
  color: white;
  text-align: center;
  text-decoration: none;
  display: inline-block;
}

/* Responsive layout - when the screen is less than 800px wide, make the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 800px) {
  .leftcolumn, .rightcolumn {   
    width: 100%;
    padding: 0;
  }
}

/* Responsive layout - when the screen is less than 400px wide, make the navigation links stack on top of each other instead of next to each other */
@media screen and (max-width: 400px) {
  .topnav a {
    float: none;
    width: 100%;
  }
}

</style>
</head>
<body>

<div class="header">
<pre><img style = "display: inline;" src="UiTM_Universiti_Teknologi_MARA_logo.png" alt="uitm" width="250" height="100">       <h1 style = "display: inline;" >Online Marking System</h1> </pre>                 
</div>

<div class="topnav">
  <a href="user_page.php">Home</a>
  <a href="user_page1.php">Presentation</a>
   <a href="user_page2.php">Update</a>
  <a href="logout.php" style="float:right">Logout</a>
</div>

<div class="row">
  <div class="leftcolumn">
    <div class="card">
      <h2>Edit your presentation/product here</h2>

<div>
  
    <form action="functions/editPresentation.php" method="post" enctype="multipart/form-data">
    Select Image File to Upload:
    <input type="file" name="file">
	<br>
	<br>
    <input type="submit" name="submit" value="Upload">
    <input type="hidden" name="presentation_id" value="<?php echo $_GET["id"]; ?>">
    </form>
  
  
</div>


 
 
    </div>
   
  </div>
  <div class="rightcolumn">
    <div class="card">
      <h2>Profile</h2>
	
	   
	  
	
	  <h2>Welcome <span><?php echo $_SESSION['user_name'] ?></span></h2>
      <p> This is Participant Page</p>
    </div>
  
  </div>
</div>

<?php include "templates/footer.php"; ?>