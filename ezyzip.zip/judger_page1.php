<?php

@include 'config.php';

session_start();

if(!isset($_SESSION['judger_name'])){
   header('location:login_form.php');
}

?>

<?php include "templates/header.php"; ?>

<div class="topnav">
  <a href="judger_page.php">Home</a>
  <a href="judger_page1.php">Participant</a>
  <a href="logout.php" style="float:right">Logout</a>
</div>

<div class="row">
  <div class="leftcolumn">
    <div class="card">
      <h2>List of Participant </h2>
  
      <form action="functions/updatePresentationScore.php" method="POST">
        <table id="user">
          <tr>
            <th>Participant Name</th>
            <th>Presentation</th>
            <th>Give Your Score here</th>
          </tr>

          <?php 
          $sql = "SELECT presentations.*, user_form.name
          FROM presentations
          INNER JOIN user_form
          ON presentations.user_id = user_form.id
          WHERE presentations.user_id = user_form.id
          ORDER BY presentations.created_at DESC";

          $result = mysqli_query($conn, $sql);

          while($row = mysqli_fetch_assoc($result)) {
          ?>

          <tr>
            <td><?php echo $row["name"]; ?></td>
            <td>
			
              <a style="color:blue;" href="<?php echo substr($row["presentation_path"], 3); ?>" target="_blank">View</a> 
            </td>
            <td>
              <input type="text" name="score[]" value="<?php echo empty($row["score"]) ? '0' : $row["score"]; ?>" />
              <input type="hidden" name="presentation_id[]" value="<?php echo $row["presentation_id"]; ?>" />
            </td>
          </tr>

          <?php } ?>

      </table>

      <br>
      <br>
	  
      <td><button class=" button button1" type="submit">Save Change</button> </td>
      </form>      
    </div>
    
  </div>
  <div class="rightcolumn">
    <div class="card">
      <h2>Profile</h2>
   
	  <h2>Welcome <span><?php echo $_SESSION['judger_name'] ?></span></h2>
      <p> This is Judger Pages</p>
    </div>
   
   </div>
</div>


<?php include "templates/footer.php"; ?>