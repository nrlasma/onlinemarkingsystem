-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 01, 2023 at 05:50 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.3.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `user_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `presentations`
--

CREATE TABLE `presentations` (
  `presentation_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `presentation_path` text NOT NULL,
  `score` float NOT NULL,
  `judged_by` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `presentations`
--

INSERT INTO `presentations` (`presentation_id`, `user_id`, `presentation_path`, `score`, `judged_by`, `created_at`) VALUES
(3, 22, '../assets/presentations/Untitled Diagram.drawio (2).png', 5, 'Dr Abdurrahman', '2023-02-01 15:22:03'),
(4, 24, '../assets/presentations/Untitled Diagram.drawio (6).png', 30, 'Dr Abdurrahman', '2023-02-01 15:49:38'),
(5, 21, '../assets/presentations/Untitled Diagram.drawio (1).png', 60, 'Dr Abdurrahman', '2023-02-01 15:55:04'),
(7, 1, '../assets/presentations/dfd.drawio.png', 0, 'Dr Abdurrahman', '2023-02-01 16:21:56');

-- --------------------------------------------------------

--
-- Table structure for table `user_form`
--

CREATE TABLE `user_form` (
  `id` int(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` varchar(255) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_form`
--

INSERT INTO `user_form` (`id`, `name`, `email`, `password`, `user_type`) VALUES
(1, 'Sarah ', 'nurulasma359@gmail.com', '61d474d48cbaf0eda36d0795a24d4e25', 'user'),
(9, 'nrlasma', 'alsyha@boom.com', '61d474d48cbaf0eda36d0795a24d4e25', 'user'),
(19, 'naufal', 'opall@gmail.com', '202cb962ac59075b964b07152d234b70', 'admin'),
(20, 'alysha', 'alysha@gmail.com', '202cb962ac59075b964b07152d234b70', 'judger'),
(21, 'Amierul Aiman', 'aiman@gmail.com', '202cb962ac59075b964b07152d234b70', 'user'),
(22, 'PeanutButter', 'peanut@gmail.com', '202cb962ac59075b964b07152d234b70', 'user'),
(23, 'Dr Abdurrahman', 'dr@gmail.com', '202cb962ac59075b964b07152d234b70', 'judger'),
(24, 'khai', 'khai@gmail.com', '202cb962ac59075b964b07152d234b70', 'user'),
(25, 'minah', 'abc@gmail.com', '202cb962ac59075b964b07152d234b70', 'judger');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `presentations`
--
ALTER TABLE `presentations`
  ADD PRIMARY KEY (`presentation_id`);

--
-- Indexes for table `user_form`
--
ALTER TABLE `user_form`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `presentations`
--
ALTER TABLE `presentations`
  MODIFY `presentation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `user_form`
--
ALTER TABLE `user_form`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
