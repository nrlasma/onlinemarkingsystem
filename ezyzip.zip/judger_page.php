<?php

@include 'config.php';

session_start();

if(!isset($_SESSION['judger_name'])){
   header('location:login_form.php');
}

?>

<?php include "templates/header.php"; ?>


<div class="topnav">
  <a href="judger_page.php">Home</a>
  <a href="judger_page1.php">Participant</a>

  <a href="logout.php" style="float:right">Logout</a>
</div>

<div class="row">
  <div class="leftcolumn">
    <div class="card">
      <h2>Evaluation</h2>
       <img src="image/photo.png" alt="judge" width="940" height="788">
      
    </div>
    
  </div>
  <div class="rightcolumn">
    <div class="card">
      <h2>Profile</h2>
   
	  <h2>Welcome <span><?php echo $_SESSION['judger_name'] ?></span></h2>
      <p> This is Judger Pages</p>
    </div>
   
   
  </div>
</div>


<?php include "templates/footer.php"; ?>
